package com.seed.controller;

import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.seed.entity.Book;
import com.seed.service.BookService;

@Controller
public class BookController {
	@Autowired
	BookService service;	
	
	@RequestMapping("/")
	public String entryPointMethod() {
		return "homepage.jsp";
	}
	
	@RequestMapping("/view")
	public ModelAndView m1() {
		System.out.println("Entry Point method...");
		ModelAndView mv=new ModelAndView();
		List<Book> lstBooks=service.getAllBooks();
		mv.addObject("lstBooks",lstBooks);
		mv.setViewName("show.jsp");
		return mv;
	}

	@RequestMapping("/delete")
	public String m2() {
		return "deleteenter.jsp";
	}
	
	@RequestMapping("/search")
	public String m3() {
		return "searchenter.jsp";
	}
	
	@RequestMapping("/add")
	public String m4() {
		return "addeenter.jsp";
	}
	
	@RequestMapping("delbook")
	public String delBook(HttpServletRequest request) {
		int code=Integer.parseInt(request.getParameter("bcode"));
		service.deleteBook(code);
		return "homepage.jsp";
	}
	
	@RequestMapping("/searchbook")
	public ModelAndView searchBook(HttpServletRequest req) {
		int code=Integer.parseInt(req.getParameter("bcode"));
		Book bk=service.getBookByCode(code);
		
		ModelAndView mv=new ModelAndView();
		mv.addObject("bk",bk);
		mv.setViewName("info.jsp");
		return mv;		
	}
	
	@RequestMapping("/addbook")
	public String addBook(HttpServletRequest req) {
		int code=Integer.parseInt(req.getParameter("bcode"));
		String author=req.getParameter("bauth");
		String title=req.getParameter("btitle");
		String publ=req.getParameter("bpubl");
		double price=Double.parseDouble(req.getParameter("bprice"));
		Book bk=new Book(code,author,title,publ,price);
		service.addBook(bk);	
		System.out.println("Book Added!");
		return "homepage.jsp";
	}
	
	
}














