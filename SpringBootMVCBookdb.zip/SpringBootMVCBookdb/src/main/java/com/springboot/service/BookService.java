package com.springboot.service;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.dao.BookRepository;
import com.springboot.entity.Book;



@Service
public class BookService {
	@Autowired
	BookRepository repo;	
	
	public List<Book> getAllBooks(){
		return repo.findAll();
	}
	
	public Book getBookByCode(int code) {
		return repo.findById(code).get();
	}
	
	public void addBook(Book bk) {
		repo.save(bk);
	}
	
	public void deleteBook(int code) {
		repo.deleteById(code);
		System.out.println("Book Deleted!");
	}
}
