package com.springboot.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@ToString
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor

@Entity
@Table(name="hib_books")
public class Book {
	@Id
	@Column
	private int code;
	@Column(length=20)
	private String author;
	@Column(length=20)
	private String title;
	@Column(name = "publ",length=20)
	private String publication;
	@Column
	private double price;	



}
