package com.springboot.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import org.springframework.stereotype.Repository;

import com.springboot.entity.Book;

import java.util.List;



@Repository
public interface BookRepository extends JpaRepository<Book, Integer>{

    List<Book> findByAuthor(String author);
 
    //hql
    @Query("from Book where price between :mn and :mx")
    List<Book> findByRanger(@Param("mn") double min,@Param("mx") double max);
    

    

}
